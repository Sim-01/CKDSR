from data import srdata
from torch.utils.data import dataloader

class Data:
    def __init__(self, args):
        self.loader_train = None
        if not args.test_only:
            print('load trainset!!')
            train_set = srdata.SRData(args, train=True)
            self.loader_train = dataloader.DataLoader(
                    train_set, batch_size=args.batch_size,
                    shuffle=True, pin_memory=not args.cpu,
                    num_workers=args.n_threads
                    )

        print('load testset!!')
        test_set = srdata.SRData(args, train=False)
        print("test_set: ", test_set.__len__())
        self.loader_test =  dataloader.DataLoader(
                test_set, batch_size=1,
                shuffle=False, pin_memory=not args.cpu,
                num_workers=args.n_threads
                )

